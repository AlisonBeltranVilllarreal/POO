import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Factura {
    public static Scanner lector = new Scanner(System.in);
    private int id;
    private Date fechaFactura;
    private float subTotal;
    private float iva = (16 / 100);
    private float total;
    private ArrayList<Productos> productos = new ArrayList<Productos>();
    private Vendedor vendedor;

    public Factura(int id, Date fechaFactura, float subTotal,
                   float iva, float total, Vendedor vendedor) {
        this.id = id;
        this.fechaFactura = fechaFactura;
        this.subTotal = subTotal;
        this.iva = iva;
        this.total = total;
        this.vendedor = vendedor;
    }

    public int getId() {
        return id;
    }

    public Date getFechaFactura() {
        return fechaFactura;
    }

    public float getSubTotal() {
        return subTotal;
    }

    public float getIva() {
        return iva;
    }

    public float getTotal() {
        return total;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFechaFactura(Date fechaFactura) {
        this.fechaFactura = fechaFactura;
    }

    public void setSubTotal(float subTotal) {
        this.subTotal = subTotal;
    }

    public void setIva(float iva) {
        this.iva = iva;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public void imprimirFactura() {
        System.out.println("ID: " + id);
        System.out.println("Fecha Factura: " + formatFecha());
        System.out.println("Subtotal: " + subTotal);
        System.out.println("Iva: " + iva);
        System.out.println("Total: " + total);
    }

    /*public Productos agregarProducto(int id) {

    }

    public double calcularSubTotal() {

    }*/

    /*public void eliminarProducto(int id) {
        boolean ciclo = true;
        do {
            try {
                int pos;
                System.out.println("Ingrese el id del producto: ");
                id = lector.nextInt();
                //productos.remove(setId(id));
                System.out.println("Se ha eliminado el producto: " + id);
                ciclo = false;
            } catch (java.lang.IndexOutOfBoundsException Error) {
                System.out.println("Se genero una excepcion al acceder al arreglo");
            }
        } while (ciclo);
    }
*/
    public String formatFecha() {
        SimpleDateFormat sfd = new SimpleDateFormat("dd/MM/yyyy");
        String fechaFormat = sfd.format(fechaFactura);
        return fechaFormat;
    }
}
