public class Productos {
    private int id;
    private String descripcion;
    private float precio;

    public Productos(int id, String descripcion, float precio) {
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public void imprimirDatos(){
        System.out.println("ID del producto: ");
        System.out.println(id);
        System.out.println("Descripcion del producto: ");
        System.out.println(descripcion);
        System.out.println("Precio del producto");
        System.out.println(precio);
    }
}
