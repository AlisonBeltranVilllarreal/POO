import java.text.SimpleDateFormat;
import java.util.*;

public class TestFactura {
    public static Scanner lector = new Scanner(System.in);
    public static ArrayList<Persona> personas = new ArrayList<Persona>();
    public static ArrayList<Productos> productos = new ArrayList<Productos>();
    public static Cliente cliente;
    public static Vendedor vendedor;
    public static Factura factura;

    public static void main(String[] args) {
        int op = 0;
        do {
            System.out.println("1.- Alta clientes ");
            System.out.println("2.- Alta vendedores");
            System.out.println("3.- Alta productos");
            System.out.println("4.- Realizar venta");
            System.out.println("5.- Listar facturas a determinado cliente");
            System.out.println("6.- Buscar vendedor");
            System.out.println("0.- Salir");
            System.out.println("Seleccione opción: ");
            op = lector.nextInt();
            switch (op) {
                case 1:
                    personas.add(leerCliente());
                    break;
                case 2:
                    personas.add(leerVendedor());
                    break;
                case 3:
                    productos.add(leerProducto());
                    break;
                case 4:
                    String nom;
                    System.out.println("Escribe el ID del Cliente: ");
                    nom = lector.next();
                    for (Persona p : personas) {
                        if (p.getNombre().equals(nom)) {
                            ((Cliente) p).imprimirDatos();
                        }
                    }
                    break;
                case 5:
                    listarFacturaCliente();
                    break;
                case 6:
                    listarventas();
                    break;
            }
        } while (op != 0);
    }

    public static Cliente leerCliente() {
        String nombre, apellidoPaterno, apellidoMaterno, rfc, domicilio;
        int anio, mes, dia;
        Date fechaNacimiento;
        System.out.println("Nombre: ");
        nombre = lector.next();
        System.out.println("Apellido Paterno: ");
        apellidoPaterno = lector.next();
        System.out.println("Apellido Materno: ");
        apellidoMaterno = lector.next();
        System.out.println("Fecha Nacimiento: ");
        System.out.println("Dia: ");
        dia = lector.nextInt();
        System.out.println("Mes: ");
        mes = lector.nextInt();
        System.out.println("Anio: ");
        anio = lector.nextInt();
        fechaNacimiento = new Date(anio - 1900, mes - 1, dia);
        System.out.println("RFC");
        rfc = lector.next();
        System.out.println("Domicilio: ");
        domicilio = lector.next();
        return new Cliente(nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, rfc, domicilio);
    }

    public static Productos leerProducto() {
        int id;
        String descripcion;
        float precio;
        System.out.println("ID del producto: ");
        id = lector.nextInt();
        System.out.println("Descripcion del Producto: ");
        descripcion = lector.next();
        System.out.println("Precio del producto: ");
        precio = lector.nextInt();
        return new Productos(id, descripcion, precio);
    }

    public static Factura agregarProducto() {
        int id, anio, mes, dia;
        Date fechaFactura = new Date( -1900,  -1, 00);
        float subTotal, iva, total;
        System.out.println("ID del producto: ");
        id = lector.nextInt();
        System.out.println("Dia: ");
        dia = lector.nextInt();
        System.out.println("Mes: ");
        mes = lector.nextInt();
        System.out.println("Anio: ");
        anio = lector.nextInt();
        System.out.println("Subtotal: ");
        subTotal = lector.nextFloat();
        System.out.println("IVA: ");
        iva = lector.nextFloat();
        System.out.println("Total: ");
        total = lector.nextFloat();
        return new Factura(id, fechaFactura, subTotal, iva, total, vendedor);
    }

    public static void buscarVendedor() {
        System.out.println("Ingrese el vendedor que desea buscar: ");
        String cuentaBuscar = lector.next();
        int pos = -1;
        for (int i = 0; i < personas.size(); i++) {
            if (personas.get(i).getNombre() == cuentaBuscar) {
                pos = i;

                if (personas.get(pos) instanceof Vendedor) {
                    System.out.println((vendedor).getPorcentajeComision());
                    System.out.println((vendedor).getSueldoBase());
                }

                if (personas.get(pos) instanceof Cliente) {
                    System.out.println("El nombre que usted ingreso pertenece a un cliente");
                }

            }
        }
    }

    public static Vendedor leerVendedor() {
        String nombre, apellidoPaterno, apellidoMaterno, area;
        float porcentajeComision;
        int sueldoBase;
        int dia, mes, anio;
        Date fechaNacimiento = new Date(-1900, -1, 00);
        System.out.println("Nombre: ");
        nombre = lector.next();
        System.out.println("Apellido Paterno: ");
        apellidoPaterno = lector.next();
        System.out.println("Apellido Materno: ");
        apellidoMaterno = lector.next();
        System.out.println("Fecha Nacimiento: ");
        System.out.println("Dia: ");
        dia = lector.nextInt();
        System.out.println("Mes: ");
        mes = lector.nextInt();
        System.out.println("Anio: ");
        anio = lector.nextInt();
        fechaNacimiento = new Date(anio - 1900, mes - 1, dia);
        System.out.println("Area: ");
        area = lector.next();
        System.out.println("Porcentaje comision: ");
        porcentajeComision = lector.nextFloat();
        System.out.println("Sueldo base: ");
        sueldoBase = lector.nextInt();
        return new Vendedor(nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, area, porcentajeComision, sueldoBase);
    }

    public static void listarFacturaCliente() {
        String nombre;
        System.out.println("Ingrese el rfc del cliente");
        nombre = lector.next();
        for (Persona p : personas) {
            if (nombre == p.getNombre() && p instanceof Cliente)
                ((Factura) factura).imprimirFactura();
            System.out.println();
            break;
        }
    }

    public static void listarventas() {
        String nombre;
        System.out.println("Ingrese el nombre del vendedor");
        nombre = lector.next();
        for (Persona p : personas) {
            if (nombre == p.getNombre() && p instanceof Vendedor)
                ((Factura) factura).imprimirFactura();
            System.out.println();
            break;
        }
    }
}
/* Preguntas al profe
1. Que hace clase fecha?
2. Como debemos de buscar cliente si no tiene ID?  RFC
3. Opcion 4 del submenu (Calcular datos restantes de la factura)
 */


/* Redordarle a Peña:
Submenu 2 debe de poder replicar los productos que ya estan almacensados (copiar objetos)
Hacer una excepcion para no duplicar vendedores

 */