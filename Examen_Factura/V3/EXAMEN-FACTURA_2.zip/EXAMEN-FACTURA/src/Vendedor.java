import java.util.Date;

public class Vendedor extends Persona {
    private String area;
    private float porcentajeComision, dineroVentas;
    private int sueldoBase;

    public Vendedor(String nombre, String apellidoPaterno, String apellidoMaterno, Date fechaNacimiento, String area, float porcentajeComision, int sueldoBase) {
        super(nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento);
        this.area = area;
        this.porcentajeComision = porcentajeComision;
        this.sueldoBase = sueldoBase;
    }

    public String getArea() {
        return area;
    }

    public float getPorcentajeComision() {
        return porcentajeComision;
    }

    public int getSueldoBase() {
        return sueldoBase;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public void setPorcentajeComision(float porcentajeComision) {
        this.porcentajeComision = porcentajeComision;
    }

    public void setSueldoBase(int sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public void setDineroVentas(float dineroVentas) {
        this.dineroVentas = dineroVentas;
    }
    public float calcularComision() {
        return sueldoBase + ((int) (dineroVentas * porcentajeComision / 100.0));
    }

    public void imprimirDatos(){
        System.out.println("Nombre: ");
        System.out.println(nombre);
        System.out.println("Apellido Paterno: ");
        System.out.println(apellidoPaterno);
        System.out.println("Apellido Materno: ");
        System.out.println(apellidoMaterno);
        System.out.print("Fecha de nacimiento: /n" + formatFecha());
        System.out.println("Area: ");
        System.out.println(area);
        System.out.print("Comision: ");
        System.out.println((double)this.dineroVentas* this.porcentajeComision/100.0);
        System.out.println();
    }
//Agregar ID

}
